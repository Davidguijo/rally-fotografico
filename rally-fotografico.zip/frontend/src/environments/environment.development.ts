export const environment = {
    production: false,
    apiUrl: 'http://localhost/rally-fotografico/backend/api'
};
