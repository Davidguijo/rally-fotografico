export const environment = {
    production: true,
    apiUrl: 'https://deepshot.infinityfreeapp.com/api'
};
